﻿using System;
using System.Collections.Generic;
using System.Text;
using JSModuleTest.API;
namespace JSModuleTest
{
    class Runner
    {
        private const string script = "var a=1;";
        public void Run()
        {
            API.JavaScriptRuntime runtime = API.JavaScriptRuntime.Create();
            var context=runtime.CreateContext();
            JavaScriptContext.Current = context;
            var x = API.JavaScriptModuleRecord.Create(null,"root");
            JavaScriptModuleRecord.SetHostInfo(x, JavascriptModuleHostInfoKind.JsModuleHostInfo_NotifyModuleReadyCallback, new  NotifyModuleReadyCallbackDelegate( ModuleNotifyReady));
            //JavaScriptModuleRecord.SetHostInfo(x, JavascriptModuleHostInfoKind.JsModuleHostInfo_HostDefined, "root");
            JavaScriptModuleRecord.ParseScript(x, script);
            //System.Threading.Thread.Sleep(1000);
            Console.WriteLine(JavaScriptModuleRecord.RunModule(x));
        }
        private JavaScriptErrorCode ModuleNotifyReady(JavaScriptModuleRecord module, JavaScriptValue value)
        {
            System.Diagnostics.Debug.WriteLine("ModuleNotifyReady start");
            return JavaScriptErrorCode.NoError;
        }
    }
}
