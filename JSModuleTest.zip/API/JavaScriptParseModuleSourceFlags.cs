﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JSModuleTest.API
{
    public enum JavaScriptParseModuleSourceFlags
    {
        JsParseModuleSourceFlags_DataIsUTF16LE = 0x00000000,
        JsParseModuleSourceFlags_DataIsUTF8 = 0x00000001
    }
}
