﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JSModuleTest.API
{
    public delegate JavaScriptErrorCode NotifyModuleReadyCallbackDelegate(JavaScriptModuleRecord module,JavaScriptValue value);
    public struct JavaScriptModuleRecord
    {
        //public static JavaScriptModuleRecord NULLRecord=new JavaScriptModuleRecord(IntPtr.Zero);
        public readonly IntPtr reference;
        public JavaScriptModuleRecord(IntPtr reference)
        {
            this.reference = reference;
        }
        public static JavaScriptModuleRecord Create(JavaScriptModuleRecord? parent, string name)
        {
            JavaScriptValue moduleName = JavaScriptValue.FromString(name);
            JavaScriptModuleRecord result;
            if (parent.HasValue)
            {
                Native.ThrowIfError(Native.JsInitializeModuleRecord(parent.Value, moduleName, out result));
            }
            else
            {
                Native.ThrowIfError(Native.JsInitializeModuleRecordWithNullParent(null, moduleName, out result));
            }
            
            return result;
        }
        public static void ParseScript(JavaScriptModuleRecord module,string script)
        {
            var buffer=Encoding.UTF8.GetBytes(script);
            uint length = (uint)buffer.Length;
            Native.ThrowIfError( Native.JsParseModuleSource(module, JavaScriptSourceContext.None, buffer, length, JavaScriptParseModuleSourceFlags.JsParseModuleSourceFlags_DataIsUTF8, out JavaScriptValue parseException));
            if (parseException.IsValid)
            {
                string ex = parseException.ToString();
                throw new InvalidOperationException($"Parse script failed with error={ex}");
            }
        }

        public static string RunModule(JavaScriptModuleRecord module)
        {
            JavaScriptValue result;
            Native.ThrowIfError( Native.JsModuleEvaluation(module, out result));
            if (result.IsValid)
            {
                return result.ToString();
            }
            else
            {
                return null;
            }
        }

        public static void SetHostInfo(JavaScriptModuleRecord module,JavascriptModuleHostInfoKind kind,object value)
        {
            Native.ThrowIfError(Native.JsSetModuleHostInfo(module, kind, value));
        }

    }
}
