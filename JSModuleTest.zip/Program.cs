﻿using System;

namespace JSModuleTest
{
    class Program
    {
        static void Main(string[] args)
        {
            var test = new Runner();
            test.Run();
            Console.Write("OK,Press Enter to exit");
            Console.ReadLine();
        }
    }
}
