using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;

namespace Chakra.NET.UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod,DeploymentItem(@"Chakra.NET.UnitTest\Script\CoreFeature.js")]
        [DeploymentItem(@"Chakra.NET.UnitTest\Script\CoreFeature.js")]
        [DeploymentItem(@"Script\CoreFeature.js")]
        [DeploymentItem(@"Script\")]
        [DeploymentItem(@"CoreFeature.js")]
        public void TestMethod1()
        {
            Assert.IsTrue(File.Exists("CoreFeature.js"));
        }
    }
}
