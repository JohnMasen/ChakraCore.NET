﻿var a = "test";
a;